const express = require('express');
const app = express();
app.get('/login', (req, res, next) => {
    res.send('I am inside login');
});
app.get('/fast', (req, res, next) => {
    res.send('I am fast')
});
app.listen(4600, () => {
    console.log('Server running at 4600')
});
