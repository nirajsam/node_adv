/* redis-cache */

// const express = require('express');
// const fetch = require('node-fetch');
// const redis = require('redis');
// const PORT = process.env.PORT || 5000;
// const REDIS_PORT = process.env.REDIS_PORT || 6379;
// const client = redis.createClient(REDIS_PORT);
// const app = express();
// function cache(req, res, next) {
//     const { id } = req.params;
//     client.hget(id,'email',(err, data) => {
//         if (err) console.log(err);
//         else if (data != null) {
//             res.send(`Email for ${id} is ${data}`)
//         }
//         else {
//             next();
//         }
//     });
// }
// let getPost = async (req, res, next) => {
//     try {
//         console.log('Fetching Data...');
//         const { id } = req.params;
//         const response = await fetch(`https://jsonplaceholder.typicode.com/users/${id}`);
//         const data = await response.json();
//         const final_resp = data.email;
//         client.hset(id,'email',final_resp);
//         res.send(final_resp);
        
//     }
//     catch (err) {
//         res.send(err.message);
//     }
// }
// app.get('/post/:id',cache,getPost);
// app.listen(PORT, () => {
//     console.log(`Server running at ${PORT}`);
// })

/* node-cache */

const express = require('express');
const fetch = require('node-fetch');
const PORT = process.env.PORT || 5000;
const app = express();
const NodeCache = require('node-cache');
const myCache = new NodeCache();
function get(req, res, next) {
    const content = myCache.get(req.params.id);
    if (content) {
        console.log('Fetching from cache...')
        return res.status(200).send(content)
    }
    return next()
}
let getPost = async (req, res, next) => {
    try {
        console.log('Fetching from mongodb...');
        const { id } = req.params;
        const response = await fetch(`https://jsonplaceholder.typicode.com/users/${id}`);
        const data = await response.json();
        const final_resp = data.email;
        myCache.set(id, final_resp)
        res.send(final_resp);
    }
    catch (err) {
        res.send(err.message);
    }
}
app.get('/post/:id', get, getPost);
app.listen(PORT, () => {
    console.log(`Server running at ${PORT}`);
});

