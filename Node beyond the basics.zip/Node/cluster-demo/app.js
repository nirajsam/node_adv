const cluster = require('cluster');
// Check if file executed in master mode
if (cluster.isMaster) {
    // cause indexedDB.js to be executed again but in child mode
    console.log("1")
    cluster.fork()
    cluster.fork()
    cluster.fork()
}
else {
    // if no go on and create a express server
    const express = require('express');
    const app = express();
    app.get('/login', (req, res, next) => {
        res.send('I am in Login page')
    });
    console.log(`Worker ${process.pid} started`);
    app.listen(4600, () => {
        console.log('Server running at 4600')
    })
}
